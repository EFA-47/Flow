using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Stone : Obstacles
{
    // 1 health, fallable, only breakable by tnt, not gem blasts
    public override void Start()
    {
        base.Start();
        health = 1;
        fallable = false;
        breakable = false;
    }
}
