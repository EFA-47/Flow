using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Box : Obstacles
{
    //Box has 1 health, fallable, breakable by gem blast
    public override void Start()
    {
        base.Start();
        health = 1;
        fallable = false;
        breakable = true;
    }
}
