using System.Collections;
using System.Collections.Generic;
using JetBrains.Annotations;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UIElements;

public class Board : MonoBehaviour
{
    private bool validMove;
    private int level_width;
    private int level_height;
    [SerializeField] private GameObject tilePrefab;
    [SerializeField] private GameObject [] objects;
    public GameObject [,] allFrontTiles; 
    [SerializeField] private GameObject gemSpawner;
    private GemSpawner [] gemSpawners;
    private GameObject gemSpawnerParent;
    public GameObject psParent;
    private List<GameObject> checkList;
    private List<List<GameObject>> allMatches;
    private GameManager gameManager;
    
    // Start is called before the first frame update
    void Start()
    {
        level_width = MenuManager.instance.level_width;
        level_height = MenuManager.instance.level_height;
        allFrontTiles = new GameObject[level_width, level_height];

        SetUp();

        gemSpawners = FindObjectsOfType<GemSpawner>();
        gemSpawnerParent = new();
        gemSpawnerParent.name = "GemspawnerParent";
        foreach (GemSpawner spawner in gemSpawners)
        {
            spawner.transform.parent = gemSpawnerParent.transform;
        }
        psParent = new();
        psParent.name = "PSParent";
        
        allMatches = AllMatches();
        gameManager = FindObjectOfType<GameManager>();
    }

    //Put front tiles based on the txt file for the given level
    void SetUp()
    {
        int positionX = 0;
        int positionY = 0;
        float width_start = - level_width * 0.5f + 0.5f;
        float height_start = - level_height * 0.5f - 1.5f;

        //forloop for each front tile 1 by 1
        for(float j = height_start; j<= -height_start - 4.0f; j++)
        {
            for(float i = width_start; i<= -width_start; i++)
            {
                //i and j are adjusted to dynamicly set whole grid in middle for every level
                Vector3 temp = new(i * 0.5f, j * 0.5f, 0);
                GameObject tile = new();
                tile.name = positionX + "," + positionY;
                tile.transform.position = gameObject.transform.position + temp;
                
                MakeFrontTile(tile);
                tile.transform.parent = transform;
                
                //when all front tiles are set, i set gem spawners infront of top row
                if(j >= -height_start - 4.0f)
                {
                    GameObject spawner = Instantiate(gemSpawner, tile.transform.position, Quaternion.identity);
                    if(TryGetComponent<Objects>(out Objects component))
                    {
                        component.Start();
                    }
                    spawner.GetComponent<GemSpawner>().column = positionX;
                    spawner.GetComponent<GemSpawner>().tile = tile;

                }
                positionX ++;
            }
            positionX = 0;
            positionY++;
        }
    }

    //based on the txt file for the level, makes front tile. 
    void MakeFrontTile(GameObject tile)
    {
        string [] tokens = tile.name.Split(',');
        int positionX =System.Int32.Parse(tokens[0]);
        int positionY =System.Int32.Parse(tokens[1]);

        int objToUse = GetObject(tile);
        GameObject frontTile = Instantiate(objects[objToUse], tile.transform.position, Quaternion.identity);
        frontTile.transform.parent = tile.transform;
        frontTile.name = frontTile.transform.GetChild(0).name;
        
        if(frontTile.transform.GetChild(0).TryGetComponent<Objects>(out Objects component))
        {
            component.positionX = positionX;
            component.positionY = positionY;
            component.Start();
        }
        
        allFrontTiles[positionX, positionY] = frontTile.transform.GetChild(0).gameObject;
    }

    //when 5 or more same kind of gems are popped, a tnt is placed on where it is clicked
    void MakeTNT(GameObject tile)
    {
        string [] tokens = tile.name.Split(',');
        int positionX =System.Int32.Parse(tokens[0]);
        int positionY =System.Int32.Parse(tokens[1]);

        //object 7 is tnt
        GameObject frontTile = Instantiate(objects[7], tile.transform.position, Quaternion.identity);
        frontTile.transform.parent = tile.transform;
        frontTile.name = frontTile.transform.GetChild(0).name;
        
        //sets newly made tnt components
        if(frontTile.transform.GetChild(0).TryGetComponent<Objects>(out Objects component))
        {
            component.positionX = positionX;
            component.positionY = positionY;
            component.Start();
        }
        
        //sorting order is set based on the front tiles height. 
        //this way tiles that have larger height will seem like on top of gems below them
        SpriteRenderer spriteRenderer = frontTile.GetComponentInChildren<SpriteRenderer>();
        spriteRenderer.sortingOrder = positionY;
        allFrontTiles[positionX, positionY] = frontTile.transform.GetChild(0).gameObject;
    }

    //gives a number based on txt file content for the specific front tile
    int GetObject(GameObject tile)
    {
        string [] tokens = tile.name.Split(',');
        int i =System.Int32.Parse(tokens[0]);
        int j =System.Int32.Parse(tokens[1]);
        switch (MenuManager.instance.grid[j,i])
        {
            case "r":
            return 0;

            case "g":
            return 1;

            case "b":
            return 2;

            case "y":
            return 3;

            case "bo":
            return 4;

            case "s":
            return 5;

            case "v":
            return 6;

            case "t":
            return 7;

            default:
            return Random.Range(0, 4);
        }
    }

    //finds all matches on the board, excluding obstacles to be destroyed
    //match has to have at least 2 objects
    //tnt is counted for the match
    List<List<GameObject>> AllMatches()
    {
        List<List<GameObject>> allMatches = new();
        List<GameObject> match;
        GameObject frontTile;
        checkList = new();
        
        for(int i = 0; i< level_height; i++)
        {
            for(int j = 0; j < level_width; j++)
            {
                //j,i beacuse reads from left to right, then higher
                frontTile = allFrontTiles[j,i];
                //gems that have been checked before are skipped
                //saves time and prevents duplicate matches
                if(!checkList.Contains(frontTile))
                {
                    match = FindMatches(frontTile,null);
                    if(match != null && match.Count > 1)
                    {
                        allMatches.Add(match);
                        //makes tnt hint if 5 or more gems are adjasend
                        if(match.Count > 4 && match[0].name != "TNT")
                        {
                            foreach (GameObject item in match)
                            {   
                                item.GetComponent<Gem>().TNTSprite();
                            }
                        }
                    }
                }
            }
        }
        
        return allMatches;
    }

    List<GameObject> FindMatches(GameObject frontTile, List<GameObject> visited)
    {
        //if stone or box is preventing falling, some tiles can be empty
        if(frontTile == null)
        {
            return null;
        }
        //if visited is null, this is the first gem in the group. make new visited list
        //immedietly add to visited, so that we dont visit it again for THIS color group
        visited ??= new();
        visited.Add(frontTile);

        //no need to match obstacles
        if(frontTile.GetComponent("Obstacles"))
        {
            return visited;
        }

        //every match finding, update sprites to show if they can make tnt or not
        if(frontTile.TryGetComponent<Gem>(out Gem componen))
        {
            componen.DefaultSprite();
            checkList.Add(frontTile);
        }

        //continue loop to see if neighbors also have same type neighbors
        Objects component = frontTile.GetComponent<Objects>();
        List<string> neighbors = FindNeighbors(component.positionX, component.positionY);
        foreach(string neighbor in neighbors)
        {
            GameObject item = allFrontTiles[neighbor[0] - '0', neighbor[1] - '0'];
            if(item != null && item.name == component.name && !visited.Contains(item))
            {   
                FindMatches(item, visited);
            }
        }

        return visited;
    }

    //returns possibly 4 stirngs that contain x and y locations on the grid.
    //+-1 vertical and horizontal neighbor locations.
    //returns string array because returning 2 int values is not possible such as "x, y = findNeighbors(x, y)" 
    List<string> FindNeighbors(int positionX, int positionY)
    {
        List<string> neighbors = new();
        if(positionX > 0)
        {
            neighbors.Add((positionX - 1).ToString() + positionY.ToString());
        }
        if(positionX < level_width - 1)
        {
            neighbors.Add((positionX + 1).ToString() + positionY.ToString());
        }
        if(positionY > 0)
        {
            neighbors.Add(positionX.ToString() + (positionY - 1).ToString());
        }
        if(positionY < level_height - 1)
        {
            neighbors.Add(positionX.ToString() + (positionY + 1).ToString());
        }
        return neighbors;
    }

    //mouse clicked on gem class leads here
    public void DestroyGemGroup(GameObject gem)
    {
        validMove = false;
        if(gameManager.isPlaying)
        {   
            //checks if the clicked gem is in any of these lists
            foreach (List<GameObject> list in allMatches)
            {
                if(list.Contains(gem))
                {
                    GameObject tile = null;
                    bool makeTNT = false;

                    //checks to make tnt
                    if (list.Count > 4)
                    {
                        makeTNT = true;
                        tile = gem.transform.parent.parent.gameObject;   
                    }
                    foreach(GameObject item in list)
                    {
                        //coroutine for particle system animation on gems
                        if(item.TryGetComponent<Gem>(out Gem component))
                        {
                            component.CheckBreakable();
                            validMove = true;
                        }
                    }

                    //damages all obstacles near popped gems
                    DamageObstacles(list);
                    if (makeTNT && tile != null)
                    {
                        MakeTNT(tile);
                    }
                    break;
                }
            }

            //if mouse clicked but gems are not popped, move is not used
            if(validMove)
            {
            gameManager.SetMoveCount();
            }
        }

        //particle systems are parented. all particle systems are cleared to save storage
        DeletePS();
        StartCoroutine(FillGaps());
    }

    public void DamageObstacles(List<GameObject> list)
    {
        List<GameObject> objects = new();
        foreach(GameObject item in list)
        {
            int positionX = item.GetComponent<Gem>().positionX;
            int positionY = item.GetComponent<Gem>().positionY;
            List<string> neighbors = FindNeighbors(positionX, positionY);
            foreach(string neighbor in neighbors)
            {
                //checks if any popped gem is next to this object
                GameObject obj = allFrontTiles[neighbor[0] - '0', neighbor[1] - '0'];

                //avoids dups when 2 gems have the same object neighbor
                if(!objects.Contains(obj) && obj != null)
                {
                    objects.Add(obj);
                }
            }
        }

        //destroys boxes. Stones are not effected, vases have 1 less health 
        //coroutine for particle systems
        foreach(GameObject obj in objects)
        {
            if(obj.TryGetComponent<Obstacles>(out Obstacles component))
            {
                component.CheckBreakable();
            }
        }
    }

    //destroys large area of gems on board
    public void TNTBlast(GameObject tnt)
    {
        //when game ends, avoids a move when player clicks the tnt anyway
        //doesnt change the result but should be better this way
        if(gameManager.isPlaying)
        {
            //if 2 or more tnt are adjasond, blast is bigger instead of wider
            List<GameObject> tntList = FindMatches(tnt, null);
            int blastRadius = tnt.GetComponent<TNT>().blastRadius;
            if(tntList.Count > 1)
            {
                blastRadius = 7;
            }

            //get all gems in 5x5 or 7x7 area
            int startX = tnt.GetComponent<Objects>().positionX - blastRadius/2;
            int startY = tnt.GetComponent<Objects>().positionY - blastRadius/2;

            int endX = tnt.GetComponent<Objects>().positionX + blastRadius/2;
            int endY = tnt.GetComponent<Objects>().positionY + blastRadius/2;

            //to avoid weird object falls and move count
            bool TNTBlasted = false;
            foreach (GameObject item in tntList)
            {
                if(item.TryGetComponent<Objects>(out Objects component))
                {
                    //delete all tnt's adjasond so 7x7 is blasted properly
                    //tnt particle systems are left on hierarchy :(
                    allFrontTiles[component.positionX, component.positionY] = null;
                    component.effect.Play();
                    component.effect.transform.parent = null;
                    Destroy(item);
                }
            }

            //destroy objects on 5x5 or 7x7 area
            //fastforwards to marked area
            for (int j = startY; j <= endY; j++)
            {
                for (int i = startX; i <= endX; i++)
                {
                    while(i < 0)
                    {
                        i++;
                    }
                    while(j < 0)
                    {
                        j++;
                    }
                    if(i >= level_width)
                    {
                        continue;
                    }
                    if(j >= level_height)
                    {
                        continue;
                    }

                    //chain reaction for TNT's
                    GameObject frontTile = allFrontTiles[i,j];
                    if(frontTile != null && frontTile.TryGetComponent<Objects>(out Objects component))
                    {
                        if(component.name == "TNT")
                        {
                            TNTBlasted = true;
                        }
                        //2nd decrease health because stone is getting damaged by only this one
                        StartCoroutine(component.DecreaseHealth());
                    }
                }
                
            }
            //when all chain reaction TNT objects are popped, continue
            if(!TNTBlasted)
            {
                gameManager.SetMoveCount();
                StartCoroutine(FillGaps());
            }
        }
        
    }

    public IEnumerator FillGaps()
    {
        yield return new WaitForEndOfFrame();
        //each fallable object is triggered to move lower
        foreach(GameObject item in allFrontTiles)
        {
            if(item != null && item.TryGetComponent<Objects>(out Objects component))
            {
                component.FallObject();
            }
        }
        //if gaps are filledi new gaps are created at top
        //new gems means new matches
        SpawnGems();
        allMatches = AllMatches();
    }

    //spawners are triggered to spawn new gems until column is full
    public void SpawnGems()
    {
        foreach (GemSpawner spawner in gemSpawners)
        {
            spawner.SpawnGem();
        }
    }

    //particle systems that are detached from objects are deleted to keep resources
    public void DeletePS()
    {
        if (psParent != null)
        {
            foreach (Transform child in psParent.transform)
            {
                Destroy(child.gameObject);
            }
        }
    }
}