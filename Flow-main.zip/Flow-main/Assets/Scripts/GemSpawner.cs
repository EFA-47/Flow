using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GemSpawner : MonoBehaviour
{
    public GameObject [] gemCollection;
    public int column;
    private Board board;
    public GameObject tile;
    private int topRow;
    
    // Spawns one gem on its self when the tile is empty
    void Start()
    {
        board = FindObjectOfType<Board>();
        topRow = MenuManager.instance.level_height - 1;
        transform.name = "Spawner " + column;
    }

    public void SpawnGem()
    {   
        if(board.allFrontTiles[column, topRow] == null)
        {
            GameObject gemToSpawn = Instantiate(gemCollection[RandomGem()], tile.transform.position, Quaternion.identity);
            gemToSpawn.transform.parent = tile.transform;
            gemToSpawn.name = gemToSpawn.transform.GetChild(0).name;

            if(gemToSpawn.transform.GetChild(0).TryGetComponent<Objects>(out Objects component))
            {
                component.positionX = column;
                component.positionY = topRow;
                component.Start();
            }

            SpriteRenderer spriteRenderer = gemToSpawn.GetComponentInChildren<SpriteRenderer>();
            spriteRenderer.sortingOrder = topRow;
            board.allFrontTiles[column, topRow] = gemToSpawn.transform.GetChild(0).gameObject;
            component.FallObject();
            SpawnGem();
        }
    }

    int RandomGem()
    {
        return Random.Range(0,gemCollection.Length);
    }
}
