using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI moveCountText;
    [SerializeField] private TextMeshProUGUI boxCountText;
    [SerializeField] private TextMeshProUGUI stoneCountText;
    [SerializeField] private TextMeshProUGUI vaseCountText;
    private int moveCount;
    private int boxCount;
    private int stoneCount;
    private int vaseCount;
    private int objectCount;
    [SerializeField] private GameObject boxCheck;
    [SerializeField] private GameObject stoneCheck;
    [SerializeField] private GameObject vaseCheck;
    [SerializeField] private GameObject boxSprite;
    [SerializeField] private GameObject stoneSprite;
    [SerializeField] private GameObject vaseSprite;
    [SerializeField] private GameObject star;
    [SerializeField] private GameObject topUI;
    [SerializeField] private GameObject transparentBlack;
    [SerializeField] private TextMeshProUGUI perfect;
    [SerializeField] private GameObject UIRibbon;
    [SerializeField] private GameObject UIBase;
    [SerializeField] private Button LevelButton;
    [SerializeField] private Button CloseButton;
    [SerializeField] private TextMeshProUGUI levelText;
    [SerializeField] private GameObject KingCry;
    private AudioSource audioSource;
    [SerializeField] private AudioClip audioClip;
    public bool isPlaying = true;
    // Works in Game Scene, tracks canvas elements and HUD
    void Start()
    {
        // Added plus 1, when move count is set it will decrease move count by 1 automaticly
        moveCount = MenuManager.instance.move_count +1;
        SetMoveCount();
        SetBoxCount();
        SetStoneCount();
        SetVaseCount();
        topUI.SetActive(true);
        transparentBlack.SetActive(false); // all but star and banner are faded black
        star.SetActive(false);
        perfect.gameObject.SetActive(false);
        audioSource = gameObject.AddComponent<AudioSource>();
        audioSource.clip = audioClip;
    }
    
    public void SetMoveCount()
    {
        moveCount -=1;
        moveCountText.text = moveCount.ToString();
        //when a move is made, check if any object has been destroyed
        StartCoroutine(UpdateObjectCounts());
    }
    
    // only used at the begining of level
    // if level has no this obstacle type, no sprite or checkbox will appear
    public void SetBoxCount()
    {
        boxCount = FindObjectsOfType<Box>().Length;
        boxCheck.SetActive(false);
        boxCountText.text = "";
        if (boxCount > 0)
        {
            boxCountText.gameObject.SetActive(true);
            boxSprite.SetActive(true);
            boxCountText.text = boxCount.ToString();
        }
    }
    public void SetStoneCount()
    {
        stoneCount = FindObjectsOfType<Stone>().Length;
        stoneCheck.SetActive(false);
        stoneCountText.text = "";
        if (stoneCount > 0)
        {
            stoneCountText.gameObject.SetActive(true);
            stoneSprite.SetActive(true);
            stoneCountText.text = stoneCount.ToString();
        }
    }
    public void SetVaseCount()
    {
        vaseCount = FindObjectsOfType<Vase>().Length;
        vaseCheck.SetActive(false);
        vaseCountText.text = "";
        if (vaseCount > 0)
        {
            vaseCountText.gameObject.SetActive(true);
            vaseSprite.SetActive(true);
            vaseCountText.text = vaseCount.ToString();
        }
    }

    //sets all numbers of obstacles
    //coroutine because moves may not be finished when this function is called
    //wait a very small amount of time to set counts correctly
    public IEnumerator UpdateObjectCounts()
    {
        yield return new WaitForSeconds(.1f);
        if(boxSprite.activeSelf)
        {
            boxCount = FindObjectsOfType<Box>().Length;
            if(boxCount > 0){
                boxCountText.text = boxCount.ToString();
            }
            else
            {
                boxCheck.SetActive(true);
                boxCountText.text = "";
            }
        }
        
        if(stoneSprite.activeSelf)
        {
            stoneCount = FindObjectsOfType<Stone>().Length;
            if(stoneCount > 0){
                stoneCountText.text = stoneCount.ToString();
            }
            else
            {
                stoneCheck.SetActive(true);
                stoneCountText.text = "";
            }
        }
        
        
        if(vaseSprite.activeSelf)
        {
            vaseCount = FindObjectsOfType<Vase>().Length;
            if(vaseCount > 0){
                vaseCountText.text = vaseCount.ToString();
            }
            else
            {
                vaseCheck.SetActive(true);
                vaseCountText.text = "";
            }
        }
        

        objectCount = boxCount+ stoneCount+ vaseCount;
        if(isPlaying)
        {
            // case player wins, make celebration and increase player level
            if(objectCount <= 0)
            {
                SetUIRibbon();
                MenuManager.instance.player_level += 1;
                StartCoroutine(Celebration());
            }
            //player loses level, obstacles left and no more moves. Only show banner
            else if (moveCount <= 0)
            {
                SetUIRibbon();
                KingCry.SetActive(true);
                audioSource.Play();
            }
        }
        
    }

    // when game ends, show ribbon, banner, level text
    public void SetUIRibbon()
    {
        isPlaying = false;
        levelText.text = "Level " + MenuManager.instance.player_level;
        levelText.gameObject.SetActive(true);
        UIRibbon.SetActive(true);
        UIBase.SetActive(true);
        CloseButton.gameObject.SetActive(true);
        LevelButton.gameObject.SetActive(true);
    }

    // Save player progress, dark background, star with anim and particle system
    public IEnumerator Celebration()
    {
        MenuManager.instance.SavePlayer();
        MenuManager.instance.LoadPlayer();
        MenuManager.instance.LoadLevel();

        transparentBlack.SetActive(true);
        transparentBlack.GetComponent<SpriteRenderer>().color = new Color(1f,1f,1f,.98f);

        star.SetActive(true);
        Animator animator = star.GetComponent<Animator>();
        animator.Play("starAnimation", 0);
        star.GetComponentInChildren<ParticleSystem>().Play();

        perfect.gameObject.SetActive(true);
        yield return new WaitForSeconds(5);
        
    }

    // If player won, button will be used to go next level. else, same level is played by the same button
    // When all levels are done, player level is 0 to show finished button
    // level 0 is playable to quickly restart the game
    public void NextLevel()
    {
        if(MenuManager.instance.player_level > 10)
        {
            MenuManager.instance.player_level = 0;
            MenuManager.instance.SavePlayer();
            SceneManager.LoadScene(0);
        }
        else
        {
            SceneManager.LoadScene(1);
        }
        
    }

    // red X button will be used to load menu
    public void BackToMenu()
    {
        SceneManager.LoadScene(0);
    }
}
