using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using System.IO;

public class MenuManager : MonoBehaviour
{
    public static MenuManager instance;
    public int level_number;
    public int level_width;
    public int level_height;
    public int move_count;
    public string [,] grid;
    public int player_level;
    private bool completed = false;

    //Awake is called to start before other Start() methods are called
    void Awake()
    {
        //singleton, only one instance is created. It is made static to be called from other classes
        if(instance != null)
        {
            Destroy(gameObject);
            return;
        }
        instance = this;
        
        //allows testing levels. set player level in canvas to 0 to play normally
        if(player_level < 1 )
        {
            LoadPlayer();
        }
        
        if(!completed)
        {
            LoadLevel();
        }
    }

    //button uses to go next level, gamescene
    public void StartNew()
    {
        //if (player_level != 0)
        // uncomment this to make sure player doesnt restart the game after finishing
        {
            SceneManager.LoadScene(1);
        }
        
    }

    //class to read txt files
    [System.Serializable]
    class Levels
    {
        public int level_number;
        public int grid_width;
        public int grid_height;
        public int move_count;
        public string [] grid;
    }

    //player number is kept in persisent data path so player dont need to restart whole game
    [System.Serializable]
    class Player_Level
    {
        public int player_level;
    }

    //when a level is passed, saves players level into persistent data path
    public void SavePlayer()
    {
        Player_Level data = new();
        data.player_level = player_level;
        string json = JsonUtility.ToJson(data);
        //player level is kept in persistent data path and json file named saveplayer
        File.WriteAllText(Application.persistentDataPath + "/saveplayer.json", json);
    }

    //before starting a game, get players level
    public void LoadPlayer()
    {
        //read the player level from persistent data path saveplayer
        //player level is kept here when application is started later on
        string path = Application.persistentDataPath + "/saveplayer.json";
        if(File.Exists(path))
        {   
            string json = File.ReadAllText(path);
            Debug.Log("Loaded JSON: " + json);
            Player_Level data = JsonUtility.FromJson<Player_Level>(json);
            if(data.player_level > 10){
                completed = true;
            }else{
                player_level = data.player_level;
            }
        }else{
            player_level = 1;
        }
    }

    //get all information about the level, player is currently at
    public void LoadLevel()
    {
        // levels are in folder noArea
        // get levels with D2 so levels are searched as 01 02 03 ... 10
        string path = Application.dataPath + "/CaseStudyAssetsNoArea/Levels/level_" + player_level.ToString("D2") + ".json";
        if(File.Exists(path))
        {   
            string json = File.ReadAllText(path);
            Levels data = JsonUtility.FromJson<Levels>(json);

            level_number = data.level_number;
            level_width = data.grid_width;
            level_height = data.grid_height;
            move_count = data.move_count;
            
            //fill grid for initial board state
            grid = new string [level_height, level_width];
            for(int i=0; i<level_height; i++)
            {
                for(int j = 0; j< level_width; j++)
                grid[i,j] = data.grid[i * level_width + j];
            }
        }
    }
}
