using UnityEngine;

public class BackgroundScaler : MonoBehaviour
{
    private Board board;
    private SpriteRenderer spriteRenderer;
    private int level_width;
    private int level_height;

    //sets the border around board for nice looks
    void Start()
    {
        board = FindObjectOfType<Board>();
        spriteRenderer = gameObject.GetComponent<SpriteRenderer>();

        AdjustBackgroundSize();
        //set into 1 block lower the middle of the board, great as the grid is always in the middle nomatter the size
        gameObject.transform.position = new(0,-1f,1);
    }

    //each blocks size is 0.5f
    //added 0.35f to count for edge size
    void AdjustBackgroundSize()
    {
        level_width = MenuManager.instance.level_width;
        level_height = MenuManager.instance.level_height;
        
        //0.5f beacuse object size is 0.5f
        float sprite_width = level_width * 0.5f + 0.35f;
        float sprite_height = level_height * 0.5f + 0.35f;

        spriteRenderer.size = new(sprite_width, sprite_height);
    }
}

