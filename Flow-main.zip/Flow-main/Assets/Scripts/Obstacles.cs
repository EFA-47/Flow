using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Obstacles : Objects
{
    // obstacles are box stone and vase, with obstacle properties
    public bool breakable = true;
}
