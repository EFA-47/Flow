using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Objects : MonoBehaviour
{
    protected bool fallable;
    public int positionX;
    public int positionY;
    protected int health;
    protected string type;
    protected SpriteRenderer spriteRenderer;
    protected Board board;
    public ParticleSystem effect;

    // objects are gems obstacles and tnt
    // all objects have positions and effects
    public virtual void Start()
    {
        board = FindObjectOfType<Board>();
        spriteRenderer = gameObject.GetComponent<SpriteRenderer>();
        spriteRenderer.sortingOrder = positionY;
        type = spriteRenderer.name;
        effect = gameObject.transform.parent.GetComponentInChildren<ParticleSystem>();
    }

    // a method to move objects below if empty. occurs immedietly
    // calls itself, recursive to keep filling empty tiles
    public virtual void FallObject()
    {
        if (positionY > 0 && board.allFrontTiles[positionX, positionY - 1] == null && fallable)
        {
            // move object down
            board.allFrontTiles[positionX, positionY - 1] = board.allFrontTiles[positionX, positionY];
            board.allFrontTiles[positionX, positionY] = null;  
            positionY -= 1;
            spriteRenderer.sortingOrder -=1;

            // when object moves, its tile is changed. This switches the transform to respective parent in board transform
            Transform newParent = board.transform.GetChild(MenuManager.instance.level_width * positionY + positionX);
            transform.parent.parent = newParent;
            Vector3 targetPosition = newParent.position;
            transform.parent.GetComponentInChildren<ParticleSystem>().transform.position = newParent.position;

            //object moved alread. smooth fall plays for nice animation
            StartCoroutine(SmoothFall(targetPosition));
            FallObject();
        }
    }

    // Smoothfall allows nice animation. it takes time, so ienumerator is used
    protected virtual IEnumerator SmoothFall(Vector3 targetPosition)
    {
        Vector3 startPosition = transform.position;
        float elapsedTime = 0f;
        float fallSpeed = 2;
        float journeyTime = Vector3.Distance(startPosition, targetPosition) / fallSpeed;
        
        // object falls in same speed with variable fallspeed
        while (elapsedTime < journeyTime)
        {
            transform.position = Vector3.Lerp(startPosition, targetPosition, elapsedTime / journeyTime);
            elapsedTime += Time.deltaTime;
            yield return null;
        }

        transform.position = targetPosition;
    }

    // used when gemgroup is destroyed
    // ienumerator is used to keep effect playing even when object is destroyed
    // after elapsed time, effect is sent to effectParent to destroy partical immedietly
    public virtual IEnumerator DecreaseHealth()
    {
        health -= 1;
        if(health < 1)
        {
            board.allFrontTiles[positionX,positionY] = null;
            effect.Play();
            effect.transform.parent = null;
            Destroy(gameObject.transform.parent.gameObject);
            yield return new WaitForSeconds(3);
            effect.transform.parent = board.psParent.transform;
        }
    }

    // if object is breakable by gem blasts, damage them
    // if object is not breakable like stone, dont damage
    public virtual void CheckBreakable()
    {
        if(TryGetComponent<Obstacles>(out Obstacles component))
        {
            if(component.breakable)
            {
                StartCoroutine(DecreaseHealth());
            }
        }
        else
        {
            StartCoroutine(DecreaseHealth());
        }
    }
}
