using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TNT : Objects
{
    public int blastRadius = 5;

    // Start is called before the first frame update
    public override void Start()
    {
        base.Start();
        health = 1;
        fallable = true;
    }

    // player triggers tnt blast, no health decreases
    public override IEnumerator DecreaseHealth()
    {
        board.TNTBlast(this.gameObject);
        yield return new WaitForSeconds(0);
    }

    // player clicks to start blast
    void OnMouseDown()
    {
        StartCoroutine(DecreaseHealth());
    }
}
