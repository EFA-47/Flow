using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.Design.Serialization;
using UnityEngine;
using UnityEngine.Animations;

public class Vase : Obstacles
{
    [SerializeField] private Sprite[] healthSprites;

    // vase has 2 health, falls and breakable by gems
    public override void Start()
    {
        base.Start();
        health = 2;
        fallable = true;
        breakable = true;
    }

    //change sprite when health is decreased
    public override IEnumerator DecreaseHealth()
    {
        StartCoroutine(base.DecreaseHealth());
        if (health < 2)
        {
            spriteRenderer.sprite = healthSprites[1];
        }
        yield return new WaitForSeconds(0);
    }
}
