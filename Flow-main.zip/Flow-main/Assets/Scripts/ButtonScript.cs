using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ButtonScript : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI text;

    // Sets text to match the level
    //if all levels are finished, writes finished
    void Start()
    {
        int level = MenuManager.instance.player_level;
        if (level < 11 && level > 0)
        {
            text.text = "Level " + level.ToString();
        }
        else
        {
            //player level is 11 after completing level 10
            //level is set to 0 and an empty board will show when level 0 is played
            text.text = "Finished";
        }   
    }
}
