using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Gem : Objects
{
    [SerializeField] private Sprite [] sprites;

    // Gems are fallable and have 1 health
    public override void Start()
    {
        base.Start();
        health = 1;
        fallable = true;
    }

    // Mouse click activates gem group destruction, nomatter the valid move 
    void OnMouseDown()
    {
        board.DestroyGemGroup(gameObject);
    }

    // Normal sprite, match has less than 5 members
    public void DefaultSprite()
    {
        spriteRenderer.sprite = sprites[0];
    }

    // has more than 5 members, shows tnt hint
    public void TNTSprite()
    {
        spriteRenderer.sprite = sprites[1];
    }
}
